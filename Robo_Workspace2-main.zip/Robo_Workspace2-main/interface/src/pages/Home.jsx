const Home = () => (
  <div className='p-8'>
    <h1 className='text-3xl font-bold'>Welcome to RoboAnalyzer</h1>
    <p className='mt-2'>Ask questions or join our community chat!</p>
  </div>
);
export default Home;
